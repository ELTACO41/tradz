const fs = require('fs');
const path = require('path');

const address = process.argv[2];
if (!address) {
  console.log("Usage: node scripts/writeFrontendEnv.js <DEPLOYED_ADDRESS>");
  process.exit(1);
}
const envPath = path.join(__dirname, '../frontend/.env.local');
fs.writeFileSync(envPath, `NEXT_PUBLIC_CONTRACT_ADDRESS=${address}\n`);
console.log(`Wrote contract address to frontend/.env.local`);