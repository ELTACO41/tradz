import React, { useEffect, useState } from 'react';

export default function AIProductSuggestions({ products }) {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    async function fetchSuggestions() {
      setLoading(true);
      setError("");
      try {
        const response = await fetch('/api/llm-suggestions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ products })
        });
        if (!response.ok) throw new Error('LLM API request failed');
        const data = await response.json();
        setSuggestions(data.suggestions || []);
      } catch (error) {
        setSuggestions([]);
        setError("Could not fetch AI suggestions.");
        console.error('Error fetching AI suggestions:', error);
      }
      setLoading(false);
    }
    if (products && products.length > 0) fetchSuggestions();
  }, [products]);

  return (
    <div>
      <h3>AI Product Suggestions</h3>
      {loading && <p>Loading suggestions...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {!loading && !error && suggestions.length === 0 && <p>No suggestions available.</p>}
      {!loading && !error && suggestions.length > 0 && (
        <ul>
          {suggestions.map((s, i) => <li key={i}>{s}</li>)}
        </ul>
      )}
    </div>
  );
}