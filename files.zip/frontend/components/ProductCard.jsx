import React from 'react';

export default function ProductCard({ product }) {
  return (
    <div style={{
      border: '1px solid #ddd',
      padding: 16,
      borderRadius: 8,
      width: 200,
      margin: 8
    }}>
      <h4>{product.name}</h4>
      <div>Seller: {product.seller}</div>
      <div>Price: {product.price} {product.token}</div>
      <div>Status: {product.sold ? "Sold" : "Available"}</div>
      {/* Add buy button logic here */}
    </div>
  );
}