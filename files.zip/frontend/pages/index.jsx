import React, { useEffect, useState } from 'react';
import ProductCard from '../components/ProductCard';
import AIProductSuggestions from '../components/AIProductSuggestions';

export default function Home() {
  const [products, setProducts] = useState([
    // Example product; replace with actual blockchain fetch logic
    { id: 1, name: "Sample NFT", seller: "0x...", price: "1.0", token: "ETH", sold: false }
  ]);

  return (
    <div>
      <h1>TRADZ Crypto Marketplace</h1>
      <div style={{ display: "flex", gap: 16 }}>
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
      <AIProductSuggestions products={products} />
    </div>
  );
}