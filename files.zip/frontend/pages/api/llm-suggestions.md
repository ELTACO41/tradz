# `/api/llm-suggestions` — AI Product Suggestions Endpoint

**POST** `/api/llm-suggestions`

Request Body:
```json
{
  "products": [
    {"name": "T-Shirt", "desc": "Cotton, Large", "price": "1 ETH", ...},
    ...
  ]
}
```

Response:
```json
{
  "suggestions": [
    "Bundle with matching cap for a discount",
    "Suggest eco-friendly packaging",
    ...
  ]
}
```

- Returns an array of AI-generated product suggestions based on the provided products.
- Handles errors gracefully, returns `{ suggestions: [] }` on failure.