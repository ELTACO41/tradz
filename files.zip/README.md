# TRADZ — Fully Functional AI-Powered Crypto Marketplace

## Overview

TRADZ is a decentralized marketplace for crypto-native products, powered by smart contracts and enhanced with AI product suggestions.

## Folder Structure

```
contracts/         # Solidity smart contract
frontend/          # React + Next.js frontend
  components/      # ProductCard and AIProductSuggestions
  pages/           # Main page and API route
  utils/           # contractABI.json
scripts/           # Deployment and utility scripts
test/              # Hardhat tests and mocks
```

## Running Locally

1. **Install dependencies:**
   ```bash
   npm install
   cd frontend && npm install
   cd ..
   ```

2. **Compile and Test Contracts:**
   ```bash
   npx hardhat compile
   npx hardhat test
   ```

3. **Deploy Contract:**
   ```bash
   npx hardhat run --network base_testnet scripts/deploy.js
   node scripts/writeFrontendEnv.js <DEPLOYED_ADDRESS>
   ```

4. **Start Frontend:**
   ```bash
   cd frontend
   npm run dev
   # Visit http://localhost:3000
   ```

5. **Connect wallet, list products, check AI suggestions.**

## Environment Variables

See `.env.local.example` and set:
```
NEXT_PUBLIC_CONTRACT_ADDRESS=0xYourDeployedContractAddress
NEXT_PUBLIC_NFT_STORAGE_KEY=your-nftstorage-key
DEPLOYER_PRIVATE_KEY=your-wallet-key
BASE_TESTNET_RPC_URL=https://your-base-testnet-node
LLM_API_KEY=your-llm-api-key
```

## API Documentation

### `/api/llm-suggestions` (POST)

Request:
```json
{ "products": [{ "name": "...", "desc": "...", "price": "...", ... }] }
```
Response:
```json
{ "suggestions": ["...", "..."] }
```

## Deployment

- **Vercel:** Link repo, set env vars, deploy.
- **Remix.gg:** Zip frontend, upload.

## .gitignore

```gitignore
.env.local
.env
node_modules/
frontend/node_modules/
build/
artifacts/
.cache/
coverage/
*.log
.DS_Store
```

---

## Next Steps

- Test ERC20/native purchases.
- Add more tests and LLM suggestion cases.
- Improve AI prompt engineering.
- Add CONTRIBUTING.md and open issues for feedback.