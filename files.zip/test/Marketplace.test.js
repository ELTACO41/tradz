const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Marketplace", function () {
  let marketplace, erc20, owner, seller, buyer, productId;

  beforeEach(async function () {
    [owner, seller, buyer] = await ethers.getSigners();
    const ERC20Mock = await ethers.getContractFactory("ERC20Mock");
    erc20 = await ERC20Mock.deploy("MockToken", "MTK", owner.address, ethers.utils.parseEther("10000"));
    await erc20.deployed();

    const Marketplace = await ethers.getContractFactory("Marketplace");
    marketplace = await Marketplace.deploy();
    await marketplace.deployed();
  });

  it("should list a product", async function () {
    await expect(marketplace.connect(seller).listProduct("Test", ethers.utils.parseEther("1"), erc20.address))
      .to.emit(marketplace, "ProductListed");
    const product = await marketplace.products(1);
    expect(product.name).to.equal("Test");
    productId = 1;
  });

  it("should allow ERC20 purchase", async function () {
    await marketplace.connect(seller).listProduct("ERC20Product", ethers.utils.parseEther("2"), erc20.address);
    await erc20.transfer(buyer.address, ethers.utils.parseEther("10"));
    await erc20.connect(buyer).approve(marketplace.address, ethers.utils.parseEther("2"));
    await expect(marketplace.connect(buyer).buyProduct(1))
      .to.emit(marketplace, "ProductPurchased");
    const product = await marketplace.products(1);
    expect(product.sold).to.equal(true);
  });

  it("should allow native token purchase", async function () {
    await marketplace.connect(seller).listProduct("ETHProduct", ethers.utils.parseEther("0.5"), ethers.constants.AddressZero);
    await expect(marketplace.connect(buyer).buyProduct(1, { value: ethers.utils.parseEther("0.5") }))
      .to.emit(marketplace, "ProductPurchased");
    const product = await marketplace.products(1);
    expect(product.sold).to.equal(true);
  });

  it("should withdraw funds after sale", async function () {
    await marketplace.connect(seller).listProduct("ETHProduct", ethers.utils.parseEther("0.5"), ethers.constants.AddressZero);
    await marketplace.connect(buyer).buyProduct(1, { value: ethers.utils.parseEther("0.5") });
    const sellerBalanceBefore = await ethers.provider.getBalance(seller.address);
    await expect(marketplace.connect(seller).withdraw())
      .to.emit(marketplace, "Withdrawn");
    // can't test exact balance due to gas, but can check withdraw succeeded
  });

  it("should reject purchase if already sold", async function () {
    await marketplace.connect(seller).listProduct("ETHProduct", ethers.utils.parseEther("0.5"), ethers.constants.AddressZero);
    await marketplace.connect(buyer).buyProduct(1, { value: ethers.utils.parseEther("0.5") });
    await expect(marketplace.connect(buyer).buyProduct(1, { value: ethers.utils.parseEther("0.5") }))
      .to.be.revertedWith("Already sold");
  });
});